# SMTSampler implementation based on z3 for String constraints

This is a Python implementation of the
[SMTSampler](https://dl.acm.org/doi/abs/10.1145/3240765.3240848) approach by
Dutra et al. based on the z3 SMT solver for String constraints only. It can
be used to efficiently create a large number of solutions to String constraints.

Author: [Dominic Steinhoefel](mailto:dominic.steinhoefel@cispa.de)
