import logging
import operator
import re
from decimal import Decimal
from fractions import Fraction
from functools import reduce
from typing import Dict, List, Callable, Union, Any, Tuple

import z3


class ConstraintEvaluator:
    def __init__(self):
        self.regex_cache: Dict[z3.ReRef, re.Pattern] = {}

        self.formula_translations: Dict[int, Callable[[Tuple[Any, ...]], bool]] = {
            # Propositional connectors
            z3.Z3_OP_TRUE: lambda *args: True,
            z3.Z3_OP_FALSE: lambda *args: False,
            z3.Z3_OP_AND: lambda *args: reduce(lambda a, b: a and b, args, True),
            z3.Z3_OP_OR: lambda *args: reduce(lambda a, b: a or b, args, False),
            z3.Z3_OP_IFF: lambda a, b: (a and b) or (not a and not b),
            z3.Z3_OP_NOT: lambda f: not f,
            z3.Z3_OP_IMPLIES: lambda a, b: (not a) or b,

            # Arithmetic comparisons
            z3.Z3_OP_GE: operator.ge,
            z3.Z3_OP_GT: operator.gt,
            z3.Z3_OP_LE: operator.le,
            z3.Z3_OP_LT: operator.lt,
            z3.Z3_OP_EQ: operator.eq,

            # Regular expressions
            z3.Z3_OP_SEQ_IN_RE: lambda to_match, pattern: pattern.fullmatch(to_match) is not None,
        }

        self.arith_translations: Dict[int, Callable[[List[Any]], Union[Fraction, int]]] = {
            z3.Z3_OP_SEQ_LENGTH: len,
            z3.Z3_OP_STR_TO_INT: int,
            z3.Z3_OP_ADD: operator.add,
            z3.Z3_OP_SUB: operator.sub,
            # z3.Z3_OP_UMINUS: operator.sub, # TODO: how to implement?
            z3.Z3_OP_MUL: operator.mul,
            z3.Z3_OP_DIV: lambda a, b: a / b,
            z3.Z3_OP_IDIV: lambda a, b: a // b,
            z3.Z3_OP_REM: operator.mod,
            z3.Z3_OP_MOD: operator.mod,  # TODO: difference to REM?
            z3.Z3_OP_TO_REAL: lambda r: Fraction.from_decimal(Decimal(str(r))),
            z3.Z3_OP_TO_INT: int,
            z3.Z3_OP_IS_INT: lambda i: type(i) is int,
            z3.Z3_OP_POWER: operator.pow,
        }

        self.seq_translations: Dict[int, Callable[[List[Any]], str]] = {
            z3.Z3_OP_SEQ_EXTRACT: lambda s, f, l: s[f:f + l],
        }

        self.logger = logging.getLogger(type(self).__name__)

    def eval(self, expr: z3.ExprRef) -> Union[bool, int, Fraction, str, re.Pattern]:
        # Atomic expressions
        if str(expr.decl()) == "String":
            expr: z3.SeqRef
            return expr.as_string()
        if type(expr) is z3.IntNumRef:
            expr: z3.IntNumRef
            return expr.as_long()
        if type(expr) is z3.RatNumRef:
            expr: z3.RatNumRef
            return expr.as_fraction()

        # Compound Expressions
        if type(expr) is z3.BoolRef:
            expr: z3.BoolRef
            return self.eval_formula(expr)
        if type(expr) is z3.ArithRef:
            expr: z3.ArithRef
            return self.translate_arith_expr(expr)
        if type(expr) is z3.ReRef:
            expr: z3.ReRef

            if expr not in self.regex_cache:
                self.regex_cache[expr] = re.compile(self.translate_re(expr))

            return self.regex_cache[expr]

        if type(expr) is z3.SeqRef:
            expr: z3.SeqRef
            return self.translate_seq(expr)

        raise NotImplementedError(f"Evaluation of expression of type {expr.decl()} not implemented.")

    def eval_formula(self, formula: z3.BoolRef) -> bool:
        operator = formula.decl()
        operator_kind = operator.kind()

        if operator_kind not in self.formula_translations:
            raise NotImplementedError(f"Evaluation for operator {operator} ({operator_kind}) not implemented.")

        children = list(map(self.eval, formula.children()))
        return self.formula_translations[operator_kind](*children)

    def translate_arith_expr(self, formula: z3.ArithRef) -> int:
        operator = formula.decl()
        operator_kind = operator.kind()

        if operator_kind not in self.arith_translations:
            raise NotImplementedError(f"Evaluation for operator {operator} ({operator_kind}) not implemented.")

        children = list(map(self.eval, formula.children()))
        return self.arith_translations[operator_kind](*children)

    def translate_seq(self, formula: z3.SeqRef) -> str:
        operator = formula.decl()
        operator_kind = operator.kind()

        if operator_kind not in self.seq_translations:
            raise NotImplementedError(f"Evaluation for operator {operator} ({operator_kind}) not implemented.")

        children = list(map(self.eval, formula.children()))
        return self.seq_translations[operator_kind](*children)

    def translate_re(self, z3_regex: z3.ReRef) -> str:
        operator: z3.FuncDeclRef = z3_regex.decl()
        operator_kind: int = operator.kind()

        if operator_kind == z3.Z3_OP_SEQ_TO_RE:
            result = re.escape(z3_regex.children()[0].as_string())
        elif type(z3_regex) is z3.SeqRef:
            z3_regex: z3.SeqRef
            result = re.escape(z3_regex.as_string())
        else:
            children: List[str] = list(map(self.translate_re, z3_regex.children()))

            if operator_kind == z3.Z3_OP_RE_PLUS:
                result = f"({children[0]})+"
            elif operator_kind == z3.Z3_OP_RE_STAR:
                result = f"({children[0]})*"
            elif operator_kind == z3.Z3_OP_RE_OPTION:
                result = f"({(children[0])})?"
            elif operator_kind == z3.Z3_OP_RE_CONCAT:
                result = "".join(children)
            elif operator_kind == z3.Z3_OP_RE_UNION:
                result = f"({'|'.join(children)})"
            elif operator_kind == z3.Z3_OP_RE_RANGE or str(operator) == "re.range":
                result = f"[{children[0]}-{children[1]}]"
            elif operator_kind == z3.Z3_OP_RE_LOOP:
                result = f"({children[0]}){{{z3_regex.params()[0]},{z3_regex.params()[1]}}}"
            elif operator_kind == z3.Z3_OP_RE_EMPTY_SET:
                result = ""
            elif operator_kind == z3.Z3_OP_RE_FULL_SET:
                result = "(.*)"
            elif operator_kind == z3.Z3_OP_RE_INTERSECT:
                raise NotImplementedError("Regex intersection is not supported by the Python re module. "
                                          "If this is needed, we could switch to the regex module.")
            elif operator_kind == z3.Z3_OP_RE_COMPLEMENT:
                raise NotImplementedError("General translation of regex complement is not supported, since it is "
                                          "in Python only possible for character sets. For this special case, "
                                          "we could implement it if needed.")
            else:
                raise NotImplementedError(f"Translation of operator {operator} ({operator_kind}) not implemented.")

        return result
