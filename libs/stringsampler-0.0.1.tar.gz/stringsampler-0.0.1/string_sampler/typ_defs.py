from typing import Dict, List, Tuple, Union

Symbol = str
Grammar = Dict[str, List[str]]
ParseTree = Tuple[str, List]
IncompleteParseTree = Tuple[str, Union[List, None]]
Path = Tuple[int, ...]
