import copy
import itertools
import logging
import random
from dataclasses import dataclass
from enum import Enum
from typing import List, Set, Generator, Tuple, Union, Dict, Iterable

import z3
from fuzzingbook.GrammarCoverageFuzzer import GrammarCoverageFuzzer
from fuzzingbook.GrammarFuzzer import tree_to_string
from fuzzingbook.Parser import EarleyParser

from string_sampler import helpers
from string_sampler.mutations import ParseTreeMutator, Mutation
from string_sampler.constraint_eval import ConstraintEvaluator
from string_sampler.helpers import list_to_hashable
from string_sampler.typ_defs import ParseTree, Grammar, Symbol


class InitialSolutionStrategy(Enum):
    SMT_MAX = 0,
    SMT_PURE = 1,


class HashableDict(dict):
    def __init__(self, seq=None):
        if seq is None:
            super().__init__()
        else:
            super().__init__(seq)

        self.hash: Union[None, int] = None

    def __repr__(self):
        return f"HashableDict({super().__repr__()})"

    def __hash__(self):
        if self.hash is None:
            self.hash = hash(tuple(sorted(self.to_hashable().items())))

        return self.hash

    def to_hashable(self):
        return {key: list_to_hashable(value) for key, value in self.items()}


class Assignment(HashableDict):
    def __init__(self, seq: Union[None,
                                  Dict[Symbol, ParseTree],
                                  Iterable[Tuple[Symbol, ParseTree]]] = None):
        super().__init__(seq)

    def __repr__(self):
        inner = repr({k: v for k, v in self.items()})
        return f"Assignment({inner})"

    def render(self):
        return HashableDict({symbol: tree_to_string(tree) for symbol, tree in self.items()})


@dataclass
class StringSamplerConfiguration:
    """
    Configuration options for StringSampler.

    Attributes:
        smt_max_timeout_secs        Time in seconds after which the attemt to find an initial solution using the
                                    SMT_MAX strategy will time out.
        nth_char_for_soft_constraints   When finding an initial solution using the SMT_MAX strategy, this parameter
                                        only considers every nth_char_for_soft_constraints-th character of a random
                                        seed solution.
        max_tries_find_init_solution    Number of times the SMT_MAX strategy will try to find an initial input after
                                        either the solver timed out (if smt_max_timeout_secs is > 0) or the discovered
                                        solution could not be syntactically fixed.
        reuse_initial_solution      If True, some existing solution is reused as initial solution for the next epoch.
        max_size_new_neighborhood   The number of times a new mutation is generated to explore the neighborhood.
                                    Mutations might be rejected if they're semantically invalid, so this is the
                                    maximum size of the new neighborhood for a symbol assignment.
        custom_evaluation           If set to True, a custom evaluation procedure is used for full concrete assignments.
                                    This can speed up checking validity for concrete assignments. If this does not work
                                    once because of an unsupported operation, we fall back to asking the SMT solver.
        max_combination_rounds      The maximum number of rounds elements of the neighborhood are combined to new
                                    elements. If the success rate of combining inputs is too low, will abort either way.
                                    Lower numbers lead possibly to more diversity, but lower performance. The value of
                                    this parameter in the SMTSampler paper is 5.
        alpha_min                   The minimum success rate for combining neighborhood elements. If the success rate
                                    is lower, a new epoch will be started.
        initial_solution_strategy   Whether to use the SMT_PURE or SMT_MAX strategy. SMT_MAX searches for a close
                                    solution to a random assignment, which can be time consuming, but produces a more
                                    diverse seed input. SMT_PURE uses a random assignment if it is valid, and otherwise
                                    directly queries the SMT solver and takes the result.
        debug_mode                  (De)activates some particularly expensive assertions (enabled iff True).
    """

    max_size_new_neighborhood: int = 100
    max_combination_rounds: int = 5
    smt_max_timeout_secs: int = 0
    max_tries_find_init_solution: int = 5
    nth_char_for_soft_constraints: int = 4
    reuse_initial_solution: bool = False
    custom_evaluation: bool = True
    alpha_min: float = 0.1
    initial_solution_strategy: InitialSolutionStrategy = InitialSolutionStrategy.SMT_MAX
    debug_mode: bool = False


class StringSampler:
    def __init__(self,
                 formula_with_syntax: z3.BoolRef,
                 formula_only_semantics: z3.BoolRef,
                 grammars: Dict[str, Grammar],
                 initial_solution: Union[Assignment, None] = None,
                 config: StringSamplerConfiguration = StringSamplerConfiguration()):
        self.formula_with_syntax: z3.BoolRef = formula_with_syntax
        self.formula_only_semantics: z3.BoolRef = formula_only_semantics
        self.grammars = grammars
        self.results: List[Assignment] = []
        self.symbols: Set[str] = self.get_symbols()
        self.current_base_solution: Union[None, Assignment] = initial_solution
        self.config = config

        self.fuzzers: Dict[str, GrammarCoverageFuzzer] = \
            {symbol: GrammarCoverageFuzzer(grammars[symbol]) for symbol in self.symbols}
        self.parsers: Dict[str, EarleyParser] = \
            {symbol: EarleyParser(grammars[symbol]) for symbol in self.symbols}

        self.previous_initial_solutions: Set[Assignment] = set([])

        self.evaluator = ConstraintEvaluator()

        self.logger = logging.getLogger("Z3Sampler")

    def get_solutions(self) -> Generator[Set[Assignment], None, None]:
        while True:
            # This is a generator, so it's only an endless loop if you call next() endlessly ;)

            if self.current_base_solution is not None:
                initial_solution = self.current_base_solution
            elif self.config.initial_solution_strategy == InitialSolutionStrategy.SMT_MAX:
                initial_solution = self.smtmax_initial_solution(self.config.smt_max_timeout_secs * 1000)

                if initial_solution is None:
                    self.logger.warning(f"Did not find an initial solution with the given timeout. Switching "
                                        f"to SMT_PURE strategy.")
                    initial_solution = self.smtpure_initial_solution()
            else:
                initial_solution = self.smtpure_initial_solution()

            self.previous_initial_solutions.add(initial_solution)

            self.logger.info(f"Initial solution: {initial_solution.render()}")
            yield {initial_solution.render()}

            self.current_base_solution = initial_solution

            mutation_sets: List[Set[Tuple[Mutation]]] = []  # \Sigma_\sigma^n in SMTSampler paper

            self.logger.debug("Searching for neighboring mutation_sets...")
            mutation_sets.append(self.compute_neighboring_solutions())

            new_assignments = {self.apply_mutations(mutations).render() for mutations in mutation_sets[0]}
            self.logger.info(f"Found first set of neighboring mutation_sets: {new_assignments}")
            yield new_assignments

            alpha, k, base_set = 1.0, 0, mutation_sets[0]

            while alpha >= self.config.alpha_min and k < self.config.max_combination_rounds:
                self.logger.debug(f"Searching for {k + 1}. set of assignment combinations...")
                next_assignments, alpha, base_set = self.combine(mutation_sets[k], mutation_sets[0], base_set)
                mutation_sets.append(next_assignments)

                new_assignments = {self.apply_mutations(mutations).render() for mutations in mutation_sets[k + 1]}
                self.logger.info(f"Found {k + 1}. set of assignment combinations:\n{new_assignments}")
                yield new_assignments

                k += 1

            if alpha < self.config.alpha_min:
                self.logger.info(f"Terminated epoch because of low alpha value {alpha} < {self.config.alpha_min}")

            if self.config.reuse_initial_solution:
                mutation_set = random.choice(
                    list(random.choice([mutation_set for mutation_set in mutation_sets if mutation_set])))
                self.current_base_solution = self.apply_mutations(mutation_set)
                self.logger.info(f"Using assignment {self.current_base_solution} as new initial solution")
            else:
                self.current_base_solution = None

    def smtpure_initial_solution(self):
        self.logger.debug("Getting initial assignment directly from solver.")
        random_assignment = self.generate_random_assignment()
        if self.is_valid_solution(random_assignment):
            return random_assignment

        solver = z3.Solver()
        solver.add(self.formula_with_syntax)

        if self.previous_initial_solutions is not None:
            for assignment in self.previous_initial_solutions:
                for symbol, symbol_assignment in assignment.items():
                    solver.add(z3.Not(z3.String(symbol) == z3.StringVal(symbol_assignment)))

        solver_result = solver.check()
        assert solver_result == z3.sat

        return self.model_to_assignment(solver.model())

    def smtmax_initial_solution(self, timeout: int) -> Union[None, Assignment]:
        runs = self.config.max_tries_find_init_solution
        for i in range(runs):
            random_assignment = self.generate_random_assignment()
            self.logger.info(f"Seed assignment: {random_assignment}")
            self.logger.debug("Searching for initial solution...")
            solution = self.find_closest_solution(random_assignment,
                                                  timeout=timeout,
                                                  avoid_solutions=self.previous_initial_solutions)
            self.logger.debug(f"SMT-Max Solver returned {None if solution is None else solution.render()}")

            if solution is not None:
                return solution
            else:
                self.logger.info(f"Did not find solution using SMT-MAX strategy within {timeout}ms, "
                                 f"retrying with new seed (run {i + 1} from {runs}).")

        return None

    def find_closest_solution(self,
                              assignment: Assignment,
                              avoid_solutions: Union[None, Set[Assignment]] = None,
                              timeout: int = -1) -> Union[None, Assignment]:
        optimizer = z3.Optimize()

        if timeout > 0:
            optimizer.set("timeout", timeout)

        optimizer.add(self.formula_with_syntax)

        for assignment in [] if avoid_solutions is None else avoid_solutions:
            for symbol, symbol_assignment in assignment.render().items():
                optimizer.add(z3.Not(z3.String(symbol) == z3.StringVal(symbol_assignment)))

        for symbol, symbol_assignment in assignment.render().items():
            for i, character in enumerate(symbol_assignment):
                # We only choose a subset of characters as soft constraints to speed up things
                if (i + 1) % self.config.nth_char_for_soft_constraints > 0:
                    continue
                optimizer.add_soft(self.character_at_position_equals(z3.String(symbol), i, character))

        sat_result = optimizer.check()

        if timeout > 0 and sat_result != z3.sat:
            if random.random() < .5:
                self.config.nth_char_for_soft_constraints += 1
            return None
        else:
            assert sat_result == z3.sat

        return self.model_to_assignment(optimizer.model())

    def compute_neighboring_solutions(self) -> Set[Tuple[Mutation, ...]]:
        result: Set[Tuple[Mutation, ...]] = set([])
        assignments: Set[Assignment] = set([])

        assignment = self.current_base_solution

        mutators: Dict[Symbol, ParseTreeMutator] = \
            {symbol: ParseTreeMutator(self.grammars[symbol], assignment[symbol], symbol=symbol)
             for symbol in assignment}

        i = 0
        while i < self.config.max_size_new_neighborhood:
            for symbol, symbol_assignment in assignment.items():
                if i >= self.config.max_size_new_neighborhood:
                    break

                i += 1

                # One might also store semantically invalid solutions for later mutation
                # (they might get valid eventually). See paper "Coverage Guided, Property Based Testing".
                # Not doing this currently, since combining semantically invalid mutations
                # is not promising, and otherwise we would have to integrate more mutation loops.
                mutation = mutators[symbol].mutate()

                probability = .5
                while True:
                    if random.random() < probability:
                        probability /= 2
                        mutation = mutation.combine(mutators[symbol].mutate())
                    else:
                        break

                new_symbol_assignment = mutation.apply()

                new_assignment = copy.deepcopy(assignment)
                new_assignment[symbol] = new_symbol_assignment

                if new_assignment in assignments:
                    continue

                self.logger.debug(f"Checking satisfiability of mutation")
                if not self.is_valid_solution(new_assignment):
                    self.logger.debug(f"Syntactically valid assignment {tree_to_string(new_symbol_assignment)} "
                                      f"found to be semantically invalid.")
                    continue

                self.logger.debug(f"Found new valid symbol assignment: {symbol} -> "
                                  f"{tree_to_string(new_symbol_assignment)}")
                result.add((mutation,))
                assignments.add(new_assignment)

        return result

    def combine(self,
                first_mutations_set: Set[Tuple[Mutation, ...]],
                second_mutations_set: Set[Tuple[Mutation, ...]],
                base_set: Set[Assignment]) -> \
            Tuple[Set[Tuple[Mutation, ...]], float, Set[Assignment]]:
        valid, checks = .0, .0
        next_assignment_set: Set[Tuple[Mutation, ...]] = set([])

        assert first_mutations_set
        assert second_mutations_set

        for mutations_set in (first_mutations_set, second_mutations_set):
            assert not any([len(list(filter(lambda m: m.symbol == s, mutations))) > 1
                            for s in self.symbols
                            for mutations in mutations_set]), \
                "Only one mutation per symbol allowed. Combine mutations if needed."

        first_mutations_set = [{mutation.symbol: mutation for mutation in mutations}
                               for mutations in first_mutations_set]
        second_mutations_set = [{mutation.symbol: mutation for mutation in mutations}
                                for mutations in second_mutations_set]

        mutations_one: Dict[Symbol, Mutation]
        mutations_two: Dict[Symbol, Mutation]

        for mutations_one, mutations_two in \
                itertools.product(*[first_mutations_set, second_mutations_set]):
            combination: List[Mutation] = []
            for symbol in set(mutations_one.keys()).union(set(mutations_two.keys())):
                if symbol in mutations_one and symbol in mutations_two:
                    combination.append(mutations_one[symbol].combine(mutations_two[symbol]))
                elif symbol in mutations_one:
                    combination.append(mutations_one[symbol])
                else:
                    combination.append(mutations_two[symbol])

                assert self.assert_syntactically_valid(symbol, tree_to_string(combination[-1].apply()))

            maybe_solution = self.apply_mutations(combination)

            for symbol, symbol_assignment in maybe_solution.render().items():
                assert self.assert_syntactically_valid(symbol, symbol_assignment), \
                    f"Assignment {symbol} -> {symbol_assignment} arising from combination syntactically invalid"

            if maybe_solution in base_set:
                continue

            base_set = base_set.union({maybe_solution})

            checks += 1
            if self.is_valid_solution(maybe_solution):
                next_assignment_set.add(tuple(combination))
                valid += 1

        next_alpha = 0 if checks == 0 else valid / checks
        return next_assignment_set, next_alpha, base_set

    def apply_mutations(self, mutations: Iterable[Mutation]) -> Assignment:
        assignment = copy.deepcopy(self.current_base_solution)
        for mutation in mutations:
            assignment[mutation.symbol] = mutation.apply()

        return assignment

    def is_valid_solution(self, maybe_solution: Assignment):
        instantiation = z3.substitute(self.formula_only_semantics,
                                      *tuple({z3.String(symbol): z3.StringVal(tree_to_string(symbol_assignment))
                                              for symbol, symbol_assignment
                                              in maybe_solution.items()}.items()))

        if self.config.custom_evaluation:
            try:
                return self.evaluator.eval(instantiation)
            except NotImplementedError as exc:
                self.logger.warning(f"{exc}. Falling back to evaluation using the SMT solver.")
                self.config.custom_evaluation = False
                return self.is_valid_solution(maybe_solution)
        else:
            solver = z3.Solver()
            solver.add(instantiation)

            return solver.check() == z3.sat

    def assert_syntactically_valid(self, symbol: str, symbol_assignment: str) -> bool:
        """Only use in assertions. Deactivated if debug_mode is off."""
        if not self.config.debug_mode:
            return True

        return helpers.syntactically_valid(self.parsers[symbol], symbol_assignment)

    def generate_random_assignment(self) -> Assignment:
        result = Assignment()

        for symbol in self.symbols:
            result[symbol] = list(self.parsers[symbol].parse(self.fuzzers[symbol].fuzz()))[0]

        return result

    def model_to_assignment(self, model: z3.ModelRef) -> Assignment:
        result = Assignment()

        for symbol in self.symbols:
            result[symbol] = list(self.parsers[symbol].parse(model[z3.String(symbol)].as_string()))[0]

        return result

    def get_symbols(self) -> Set[Symbol]:
        result: Set[Symbol] = set()

        def recurse(elem: z3.ExprRef):
            op = elem.decl()
            if z3.is_const(elem) and op.kind() == z3.Z3_OP_UNINTERPRETED:
                if op.range() != z3.StringSort():
                    raise NotImplementedError(
                        f"This class was developed for String symbols only, found {op.range()}")

                result.add(op.name())

            for child in elem.children():
                recurse(child)

        recurse(self.formula_with_syntax)
        return result

    @staticmethod
    def character_at_position_equals(symbol, position, character):
        return z3.SubString(symbol, z3.IntVal(position), z3.IntVal(1)) == z3.StringVal(character)
